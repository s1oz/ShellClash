import{T as a}from"./vendor-6rLqdkxq.js";import{ad as m}from"./index-BWze4VzI.js";const s=o=>a(o).locale(m()).fromNow();export{s as f};
